const Product = require('../models/ProductSchema');

const validateData = (data) => {
  if(data){
    return true;
  }
  return false;
}

const addProduct = async (req, res) => {
  try {
    // Example: creating a new user
    const { product_name, product_id,product_brand, price, quantity } = res;

    if(!validateData(product_name) || !validateData(product_id) || !validateData(product_brand) || !validateData(price) || !validateData(quantity)){
      return res.status(400).send('Missing required data');
    }

    const newProduct = new Product({
      product_name: product_name,
      product_id: product_id,
      product_brand: product_brand,
      price: price,
      quantity: quantity
    });

    await newProduct.save();

    res.send('Product created successfully');
  } catch (error) {
    console.error('Error creating product:', error);
    res.status(500).send('Internal Server Error');
  }
};

export {
  addProduct,
}
