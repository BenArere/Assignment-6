const express = require('express');
const router = express.Router();
const productController = require('./controller/productController');

// Home route
router.get('/', productController.addProduct);

module.exports = router;
