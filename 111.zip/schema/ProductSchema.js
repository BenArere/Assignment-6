const mongoose = require('mongoose');

const productSchema = new mongoose.Schema({
  product_name: {
    type: String,
    required: true,
  },
  product_id: {
    type: String,
    required: true,
    unique: true,
  },
  product_brand: {
    type: String,
    required: true,
  },
  price: {
    type: Number,
    required: true,
  },
  quantity: {
    type: Number,
    required: true,
  },

});

const Product = mongoose.model('Products', productSchema);

module.exports = Product;
